﻿using System;

namespace class2
{
    class Program
    {
        static void Main(string[] args)
        {
            //int
            int a = 12;
            Console.WriteLine(a);

            //double
            double b = 12.5;
            Console.WriteLine(b);

            //char
            char c = 'A';
            Console.WriteLine(c);

            //string
            string d = "Jaywood Professional";
            Console.WriteLine(d);

            //bool
            bool e = true; //false
            Console.WriteLine(e);
        }
    }
}
